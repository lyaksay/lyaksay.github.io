<?php

include('tmp/header.php');
?>


<div class="section content">
      <div class="container">
		<div class="row">

			<div class="col-md-12">
				<h1 data-page="2">
					<!-- Заменить на заголовок -->
				</h1>
				
				
				<!--  WORK AREA -->







				<!-- END  WORK AREA -->



			</div>
			
            
		</div>
	</div>
</div> 




<?php

include('tmp/footer.php');
?>