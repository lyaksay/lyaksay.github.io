
	<div class="section min_pad">

    </div>



    <footer class="section footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-6 col-xs-6">
                    <h3>О нашем магазине</h3>
                    <p>
						Компания RODEO-JEANS более 25 лет специализируется на джинсовой одежде
						разных стран и представляет интернет-магазин www.RODEO.MODA </br></br>
						
						Удачных вам покупок!
					</p>
                </div>
				
                <div class="col-sm-3 col-xs-6">
                    <h3>Сервис и помощь</h3>
                    <ul class="ul-reset">
		                <li><a href="#">Пункты самовывозы</a></li>
		                <li><a href="/oplata">Доставка и&nbsp;оплата</a></li>
		                <li><a href="/faq">Вопросы и ответы</a></li>
		                <li><a href="/oferta">Публичная оферта</a></li>
                     <li><a href="/uhod-za-odezhdoj">Уход за товарами</a></li>
		            </ul>
                </div>
                <div class="col-sm-3 col-xs-12">
                    <h3>О компании</h3>
                    <ul class="ul-reset">
		                <li><a href="/about">О нас</a></li>
		                <li><a href="/contact">Контакты</a></li>
		                <li><a href="#">Преимущества</a></li>
		                <li><a href="#">Наши скидки</a></li>
		                <li><a href="http://rodeo-jeans.com/order.html">Партнерам</a></li>
		                <li><a href="/vakansii">Вакансии</a></li>
		                <li><a href="/franshiza" target="_blank">Франчайзинг</a></li>
		            </ul>
				</div>
            </div>


        <div class="row">
            <div class="col-sm-12">
            	<div class="copyright">
			        © 2015 Rodeo Jeans. All Rights Reserved.
			    </div>
            </div>
        </div>


        </div>
    </footer>

	<a id="back-to-top" href="#" class="btn btn-primary btn-lg back-to-top" role="button" >
		<span class="glyphicon glyphicon-chevron-up"></span>
	</a>
	

	
	

	<link href='https://fonts.googleapis.com/css?family=Roboto:400,500,700&subset=latin,cyrillic' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/evil-icons/1.9.0/evil-icons.min.css">
	<script src="https://cdn.jsdelivr.net/evil-icons/1.9.0/evil-icons.min.js"></script>
	
	
	<!-- Скриптовое отделение -->
	<script type="text/javascript" src="https://yastatic.net/bootstrap/3.3.4/js/bootstrap.min.js"></script>
	
	<script src="https://rodeo.moda/design/rodeo/js/jasny-bootstrap.min.js"></script>
	<script src="https://rodeo.moda/design/rodeo/js/jquery-ui.min.js"></script>
	<script src="https://rodeo.moda/design/rodeo/js/ajax_cart.js"></script>

	<script src="https://rodeo.moda/design/rodeo/js/jquery.sticky-kit.min.js"></script>

    <script src="https://rodeo.moda/design/rodeo/js/sumoselect/jquery.sumoselect.js"></script>
    <script src="https://rodeo.moda/design/rodeo/js/catalog_filter.js"></script>
    <script src="https://rodeo.moda/design/rodeo/js/maskedinput.js"></script>
	
	
	<script src="https://rodeo.moda/js/baloon/js/baloon.js" type="text/javascript"></script>
	<link href="https://rodeo.moda/js/baloon/css/baloon.css" rel="stylesheet" type="text/css" />
	
	
	 

	
	<script src ="design/rodeo/js/scripts.js" type="text/javascript"></script>
	
	
	 

	
		
		<!-- Yandex.Metrika counter -->
		<script type="text/javascript">
			(function (d, w, c) { (w[c] = w[c] || []).push(function() { try { w.yaCounter30741083 = new Ya.Metrika({ id:30741083, clickmap:true, trackLinks:true, accurateTrackBounce:true, webvisor:true }); } catch(e) { } }); var n = d.getElementsByTagName("script")[0], s = d.createElement("script"), f = function () { n.parentNode.insertBefore(s, n); }; s.type = "text/javascript"; s.async = true; s.src = "https://mc.yandex.ru/metrika/watch.js"; if (w.opera == "[object Opera]") { d.addEventListener("DOMContentLoaded", f, false); } else { f(); } })(document, window, "yandex_metrika_callbacks"); 
		</script>
		<!-- /Yandex.Metrika counter -->
	
	
</body>
</html>
<!--
memory peak usage: 1448664 bytes
page generation time: 0.026618957519531 seconds
-->