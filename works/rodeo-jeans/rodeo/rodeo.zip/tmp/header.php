
<!DOCTYPE html>
<html>
<head>
	<meta name="yandex-verification" content="9d24c261bfb4a8cb" />

	<link rel="shortcut icon" type="image/x-icon" href="design/rodeo/images/favicon.png" />
	<link rel="canonical" href="https://rodeo.moda/oplata"/>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
		
	<!-- мета для обычных страниц-->
	<title>Оплата</title>
	<meta name="description" content="Оплата">
	<meta name="keywords" content="Оплата" />
	
	<!-- Стили и шрифты -->
  	<link href="https://rodeo.moda/design/rodeo/css/jasny-bootstrap.min.css?v=1510202294" rel="stylesheet" type="text/css" >
  	<link rel="stylesheet" type="text/css" href="https://rodeo.moda/design/rodeo/js/sumoselect/sumoselect.css">
	<link href="https://yastatic.net/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" type="text/css">
	<link href="https://rodeo.moda/design/rodeo/css/style.css?v=1510202294" rel="stylesheet" type="text/css" media="screen"/>
	<link href="https://rodeo.moda/design/rodeo/css/responsive.css?v=1510156204" rel="stylesheet" type="text/css" media="screen"/>
	<link rel="stylesheet" href="../css/pages.css">


	<script type="text/javascript" src="https://yastatic.net/jquery/2.0.3/jquery.min.js"></script>
	
</head>
<body>
	<div id="overlay" onclick="return (close_cart() || close_menu())"></div>

	<!-- Черная полоса -->
	<div class="section no_padding black_bg">
        <div class="container">
            <div class="row">


            <div class="visible-xs visible-sm col-xs-6">

				<nav id="myNavmenu" class="navmenu navmenu-default navmenu-fixed-left offcanvas" role="navigation">
				  <ul class="mobmenu">
				  		<!-- --> 
<li class="mobmenu__title mobmenu__title-bg">
    <a href="/catalog/zhenschinam"  class="mobmenu__title__a">Женщинам</a>
</li>
<ul class="mobmenu__row">
    <li class="mobmenu__item">
        <a href="/catalog/dzhinsy-w" class="mobmenu__item__a">Джинсы</a>
    </li>
    <li class="mobmenu__item">
        <a href="/catalog/rubashki-w" class="mobmenu__item__a">Рубашки</a>
    </li>
    <li class="mobmenu__item">
        <a href="/catalog/kurtki-w" class="mobmenu__item__a">Куртки</a>
    </li>
    <li class="mobmenu__item">
        <a href="/catalog/puhoviki-w" class="mobmenu__item__a">Пуховики</a>
    </li>
    <li class="mobmenu__item">
        <a href="/catalog/futbolki-w" class="mobmenu__item__a">Футболки</a>
    </li>
    <li class="mobmenu__item">
        <a href="/catalog/yubki-w" class="mobmenu__item__a">Юбки</a>
    </li>
    <li class="mobmenu__item">
        <a href="/catalog/tolstovki-svitshoty-w" class="mobmenu__item__a">Толстовки и свитшоты</a>
    </li>
    <li class="mobmenu__item">
        <a href="/catalog/svitery-pulovery-w" class="mobmenu__item__a">Свитеры и пуловеры</a>
    </li>
</ul>


<!-- -->
<li class="mobmenu__title mobmenu__title-bg">
    <a href="/catalog/muzhchinam"  class="mobmenu__title__a">Мужчинам</a>
</li>

<ul class="mobmenu__row">
    <li class="mobmenu__item">
        <a href="/catalog/dzhinsy-m" class="mobmenu__item__a">Джинсы</a>
    </li>
    <li class="mobmenu__item">
        <a href="/catalog/rubashki-m" class="mobmenu__item__a">Рубашки</a>
    </li>
    <li class="mobmenu__item">
        <a href="/catalog/kurtki-m" class="mobmenu__item__a">Куртки</a>
    </li>
    <li class="mobmenu__item">
        <a href="/catalog/puhoviki-m" class="mobmenu__item__a">Пуховики</a>
    </li>
    <li class="mobmenu__item">
        <a href="/catalog/tolstovki-svitshoty-m" class="mobmenu__item__a">Толстовки и свитшоты</a>
    </li>
</ul>


<!-- -->
<li class="mobmenu__title mobmenu__title-bg">
    <a href="/catalog/devochkam" class="mobmenu__title__a">Девочкам</a>
</li>
<li class="mobmenu__title mobmenu__title-bg">
    <a href="/catalog/malchikam" class="mobmenu__title__a">Мальчикам</a>
</li>

<hr>

<!-- -->
<li class="mobmenu__title">
    <a href="/brands" class="mobmenu__title__a">Бренды</a>
</li>
<li class="mobmenu__title">
    <a href="/dostavka" class="mobmenu__title__a">Доставка</a>
</li>
<li class="mobmenu__title">
    <a href="/oplata" class="mobmenu__title__a">Оплата</a>
</li>
<li class="mobmenu__title">
    <a href="/contact" class="mobmenu__title__a">Контакты</a>
</li>
				  </ul>
				</nav>

				<div class="navbar navbar-default ">
				  <button type="button" class="navbar-toggle pull-left" data-toggle="offcanvas" data-target="#myNavmenu" data-canvas="body">
				    <span class="icon-bar"></span>
				    <span class="icon-bar"></span>
				    <span class="icon-bar"></span>
				  </button>
				</div>
			</div>

			<div class="col-xs-6">
				<p class="header_phone">8 800 500-76-50
				<a href="/actions" style="color:#0AD775;" class="hidden-xs hidden-sm">БОНУСЫ И АКЦИИ</a></p>
			</div>
				
			<div class="col-xs-6 hidden-xs hidden-sm">
                <div class="pull-right">
					<p class="user_top">
											<a href="/user/register" class="">Регистрация</a>
						<a href="/user/login">Вход</a>
										</p>
				</div>
			</div>
			
            </div>
        </div>
    </div>
	
   
   <!-- ШАпка -->
	<div class="section">
        <div class="container min_pad">
            <div class="row">
               


				<div class="col-md-3 col-sm-6 col-xs-6">
					<a href="/">
						<img src="https://rodeo.moda/design/rodeo/images/logo.png" class="hidden-xs">
						<img src="https://rodeo.moda/design/rodeo/images/logo.png" class="visible-xs img-responsive">
					</a>
                </div>

				<div class="col-md-3 col-sm-6 col-xs-6 pull-right mt-15">
					<div class="pull-right">
					    <div id="favourites_informer" class='link-like '>
					        <a href="./favourites" ><span>0</span></a>
                   		</div>
						<div id="cart_informer" class='link-basket '>
						    	<a href="#"  onclick="return open_cart();" class="btn-cart">
	<span>0</span>
	</a>


<div id="cart-sidebar">
    <div id="cart-sidebar-wrapper">
       <div id="total-content"></div>
       <br><br>
       <div id="cart-content"></div>
       <div id="cart-items">
          <div id="cart-header">
             <span onclick="return close_cart()" class="nav-close nav-btn glyphicon glyphicon-menu-left"></span>
             <h3 class="text-center">Ваш заказ<span class="ng-binding">(0)</span></h3>
          </div>
                        <div class="no-products-message ng-hide" ng-hide="cart.products.length">
                 <h3>В вашем заказе, пока что нет товаров :(</h3>
                 <h4>Кажется, сейчас самое время начать покупки!</h4>
              </div>
                    <table id="shopping-cart-table" class="table" ng-show="cart.products.length">
             <tbody>
                             </tbody>
          </table>
          <div id="cart-totals" ng-show="cart.products.length" class="">
             <div id="cart-subtotal" class="cart-total-section">
                <dl>
                   <dt>Итого</dt>
                   <dd class="ng-binding">0 <span class="ruble">i</span></dd>
                </dl>
             </div>
             <div id="cart-help" class="text-center">Нужна помощь? Позвоните нам <span class="text-nowrap"><a class="phone pseudo-link" href="tel:8 800 500-76-50">8 800 500-76-50</a> 
						 </span></div>
          </div>
       </div>
       <div id="cart-checkout" class="text-center" ng-show="cart.products.length">
          <a class="orange pseudo-link" href="/cart">Оформить заказ</a>
       </div>
    </div>
</div>
                   		</div>
                    </div> 
                </div>
                
				<div class="col-md-6 hidden-xs hidden-sm mt-15">
					<form action="products" class="form-horizontal">
						<div class="form-group quick-search">
                            <div class="col-sm-12">
								<input class="input_search form-control" type="text" name="keyword" value="" placeholder="Поиск товара"/>
								<button>поиск</button>
							</div>
                        </div>
					</form>
					
                </div>
            </div>
        </div>
		
	
        <!-- Меню-->
        <nav class="container nav_block min_pad hidden-xs hidden-xs">
            <div class="row">
                <div class="col-md-12">
					
		
	  <div class="tab-pane fade in active">
		<ul class="nav nav-tabs menu_tabs_top">
			<li class="dropdown mega-dropdown">
				<a href="#" data-toggle="dropdown" class="dropdown-toggle mega-title">
					ЖЕНЩИНАМ
				</a>
			  
		<ul class="dropdown-menu mega-dropdown-menu row">
            <li class="col-sm-3">
				<ul>
					<li class="dropdown-header"><a href="/catalog/dzhinsy-w">Джинсы</a></li>
					<li><a href="/catalog/dzhinsy-w?2%5B%5D=Зауженные+джинсы">Зауженные</a></li>
					<li><a href="/catalog/dzhinsy-w?2%5B%5D=Прямые+джинсы">Прямые</a></li>
					<li><a href="/catalog/dzhinsy-w?2%5B%5D=Широкие+джинсы%2C+клеш">Широкие</a></li>
					<li><a href="/catalog/dzhinsy-w?2%5B%5D=Утепленные+джинсы">Утепленные</a></li>
					
					<li class="dropdown-header"><a href="/catalog/rubashki-w">Рубашки</a></li>
					<li><a href="/catalog/rubashki-w?2%5B%5D=Короткий+рукав">Короткий рукав</a></li>
					<li><a href="/catalog/rubashki-w?2%5B%5D=Длинный+рукав">Длинный рукав</a></li>
					<li><a href="/catalog/rubashki-w/delfin">Мерсерезированный хлопок</a></li>
				</ul>
            </li>
            <li class="col-sm-3">
				<ul>
					<li class="dropdown-header"><a href="/catalog/verhnyaya-odezhda-w">Верхняя одежда</a></li>
					<li><a href="/catalog/kurtki-w">Куртки осенние</a></li>
					<li><a href="/catalog/verhnyaya-odezhda-w?keyword=ветровка">Ветровки</a></li>
					<li><a href="/catalog/kurtki-w">Куртки зимние</a></li>
					<li><a href="/catalog/puhoviki-w">Пуховики</a></li>
					
					<li class="dropdown-header"><a onclick="return false">Трикотаж</a></li>
					<li><a href="/catalog/yubki-w">Юбки</a></li>
					<li><a href="/catalog/tolstovki-svitshoty-w">Толстовки и свитшоты</a></li>
					<li><a href="/catalog/svitery-pulovery-w">Свитеры и пуловеры</a></li>
					<li><a href="/catalog/futbolki-w">Футболки</a></li>
				</ul>
            </li>
            <li class="col-sm-3">
				<ul>
					<li class="dropdown-header"><a href="/catalog/muzhchinam?5%5B0%5D=BAT">Большие размеры</a></li>
					<li><a href="/catalog/zhenschinam?5%5B%5D=BAT">Большие размеры</a></li>
					<li><a href="/catalog/zhenschinam?5%5B%5D=BAT">Большой рост</a></li>
					<li class="dropdown-header"><a href="/catalog/zhenschinam">Вся одежда</a></li>
				</ul>
            </li>
            <li class="col-sm-3">
				<img src="/files/products/b1942d61-1066-11e7-bdde-00155d007103_1.400x.jpeg" alt="Джинсы" class="img-responsive">
            </li>
          </ul>
		  
</li> 

<!-- 
МУЖЧИНАМ
-->
<li class="dropdown mega-dropdown">
	<a href="#" data-toggle="dropdown" class="dropdown-toggle mega-title">
		МУЖЧИНАМ
	</a>
			
	<ul class="dropdown-menu mega-dropdown-menu row">
		<li class="col-sm-3">
			<ul>
				<li class="dropdown-header"><a href="/catalog/dzhinsy-m">Джинсы</a></li>
				<li><a href="/catalog/dzhinsy-m?2%5B%5D=Зауженные+джинсы">Зауженные</a></li>
				<li><a href="/catalog/dzhinsy-m?2%5B%5D=Прямые+джинсы">Прямые</a></li>
				<li><a href="/catalog/dzhinsy-m?2%5B%5D=Широкие+джинсы%2C+клеш">Широкие</a></li>
				<li><a href="/catalog/dzhinsy-m?2%5B%5D=Утепленные+джинсы">Утепленные</a></li>
					
				<li class="dropdown-header"><a href="/catalog/rubashki-m">Рубашки</a></li>
				<li><a href="/catalog/rubashki-m?2%5B%5D=Короткий+рукав">Короткий рукав</a></li>
				<li><a href="/catalog/rubashki-m?2%5B%5D=Длинный+рукав">Длинный рукав</a></li>
				<li><a href="/catalog/rubashki-m/enrico-beleno">Мерсерезированный хлопок</a></li>
			</ul>
		</li>
		<li class="col-sm-3">
			<ul>
				<li class="dropdown-header"><a href="/catalog/verhnyaya-odezhda-m">Верхняя одежда</a></li>
				<li><a href="/catalog/kurtki-m?6%5B%5D=Демисезон&6%5B%5D=Лето">Куртки осенние</a></li>
				<li><a href="/catalog/kurtki-m?6%5B%5D=Зима">Куртки зимние</a></li>
				<li><a href="/catalog/puhoviki-m">Пуховики</a></li>
				
				<li class="dropdown-header"><a  onclick="return false">Трикотаж</a></li>
				<li><a href="/catalog/tolstovki-svitshoty-m">Толстовки и свитшоты</a></li>
				<li><a href="/catalog/svitery-pulovery-m">Свитеры и пуловеры</a></li>
				<li><a href="/catalog/futbolki-m">Футболки</a></li>
				<li><a href="/catalog/polo-m">Поло</a></li>
			</ul>
		</li>
		<li class="col-sm-3">
			<ul>
				<li class="dropdown-header"><a href="/bolshie-razmery-m">Большие размеры</a></li>
				<li><a href="/catalog/bolshie-razmery-m">Большие размеры</a></li>
				<li><a href="/catalog/bolshie-razmery-m">Большой рост</a></li>
					<li class="dropdown-header"><a href="/catalog/muzhchinam">Вся одежда</a></li>
			</ul>
		</li>
		<li class="col-sm-3">
			<img src="/files/products/7324772b-9fe8-11e6-9860-00155d007103_1.400x.jpeg" alt="Джинсы" class="img-responsive">
		</li>
	</ul>
		  
</li>
			
			
<!-- 
ДЕВОЧКАМ
-->
<li class="dropdown mega-dropdown">
	<a href="#" data-toggle="dropdown" class="dropdown-toggle mega-title">
		ДЕВОЧКАМ
	</a>
			
	<ul class="dropdown-menu mega-dropdown-menu row">
		<li class="col-sm-3">
			<ul>
				<li class="dropdown-header"><a href="/catalog/devochkam">Одежда</a></li>
				<li><a href="/catalog/dzhinsiki-d">Джинсики</a></li>
				<li><a href="/catalog/kostyumchiki">Костюмчики</a></li>
				<li><a href="/catalog/shortiki-w">Шортики</a></li>
				<li><a href="/catalog/sarafany-d">Сарафанчики</a></li>
				<li><a href="/catalog/platyushki">Платьюшки</a></li>
				<li><a href="/catalog/yubka-d">Юбочки</a></li>
				<li><a href="/catalog//kurtochki-w">Курточки</a></li>
			</ul>
		</li>
		<li class="col-sm-3">
		</li>
		<li class="col-sm-3">
		</li>
		<li class="col-sm-3">
			<img src="/files/products/034fab63-cd9b-11e6-9860-00155d007103_1.300x.jpeg" class="img-responsive"/>
		</li>
	</ul>
</li>



<!-- 
МАЛЬЧИКАМ
-->
<li class="dropdown mega-dropdown">
	<a href="#" data-toggle="dropdown" class="dropdown-toggle mega-title">
		МАЛЬЧИКАМ
	</a>
			
	<ul class="dropdown-menu mega-dropdown-menu row">
		<li class="col-sm-3">
			<ul>
				<li class="dropdown-header"><a href="/catalog/malchikam">Одежда</a></li>
				<li><a href="/catalog/dzhinsiki-m">Джинсики</a></li>
				<li><a href="/catalog/kostyumchiki-m">Костюмчики</a></li>
				<li><a href="/catalog/shortiki-m">Шортики</a></li>
				<li><a href="/catalog/tolstovochki-m">Толстовки</a></li>
				<li><a href="/catalog/kurtochki-m">Курточки</a></li>
			</ul>
		</li>
		<li class="col-sm-3">
		</li>
		<li class="col-sm-3">
		</li>
		<li class="col-sm-3">
			<img src="/files/products/b1bae16e-ad3d-11e6-9860-00155d007103_1.300x.jpeg" class="img-responsive"/>
		</li>
	</ul>
</li>

		<div class="menu_right  hidden-xs hidden-xs">
<li><a href="/actions">Акции</a></li>
<li><a href="/brands">Бренды</a></li>
		</div>



		</ul>
	</div>

	
	
	
                </div>
            </div>
        </nav>
	
		
		
		
    </div>

	
	